#include "../catch/catch.hpp"

#include "../graph.h"
#include "../algorithms.h"
#include "../readFile.h"

bool listContainsNode(vector<Node> list, Node n) {
  for(unsigned i = 0; i < list.size(); i++) {
    if(list[i] == n) {
      return true;
    }
  }
  return false;
}

Node createNode(float lat, float longitude, int index) {
  Node n;
  n.latitude_ = lat;
  n.longitude_ = longitude;
  n.index_ = index;
  return n;
}

TEST_CASE("Testing shortestPath(Graph graph, Node start, Node end) function", "[weight=1][part=1]") {
  readFile f;
  Graph medium_graph = f.read("testMedium.txt");
  map<Node, vector<Node>> adj_list =  medium_graph.getAdjList();

  Node location_one;
  Node location_two;
  Node location_three;

  location_three.longitude_ = 5;
  location_three.latitude_ = 44;
  location_three.index_ = 2;

  location_one.longitude_ = 0;
  location_one.latitude_ = 45;
  location_one.index_ = 0;

  location_two.longitude_ = 2;
  location_two.latitude_ = 48;
  location_two.index_ = 1;

  SECTION("Same node") {
    int shortest_path = Algorithms::shortestPath(medium_graph, location_one, location_one);
    int actual_distance = Graph::getDistance(location_one, location_one);
    
    REQUIRE(shortest_path == actual_distance);
  }

  SECTION("One edge away") {
    int shortest_path = Algorithms::shortestPath(medium_graph, location_one, location_two);
    int actual_distance = Graph::getDistance(location_one, location_two);
    
    REQUIRE(shortest_path == actual_distance);
  }

  SECTION("2 edges away") {
    int shortest_path = Algorithms::shortestPath(medium_graph, location_one, location_three);
    int actual_distance = Graph::getDistance(location_one, location_two) + Graph::getDistance(location_one, location_three);
    
    REQUIRE(shortest_path == actual_distance);
  }

  SECTION("Multiple edges away, with multiple paths to get there") {
    Graph multi_path = f.read("testMultiplePaths.txt");
    map<Node, vector<Node>> adj_list =  multi_path.getAdjList();

    Node location_zero;
    Node location_two;

    location_zero.longitude_ = 25;
    location_zero.latitude_ = 11;
    location_zero.index_ = 0;

    location_two.longitude_ = 10;
    location_two.latitude_ = 70;
    location_two.index_ = 2;

    int shortest_path = Algorithms::shortestPath(multi_path, location_zero, location_two);
    int actual_distance = Graph::getDistance(location_zero, location_two);

    REQUIRE(shortest_path == actual_distance);
  }

  SECTION("Multiple paths to get there, larger data set") {
    Graph multi_path = f.read("testLarge.txt");
    map<Node, vector<Node>> adj_list =  multi_path.getAdjList();

    Node location_zero;
    Node location_three;

    location_zero.longitude_ = 25;
    location_zero.latitude_ = 11;
    location_zero.index_ = 0;

    location_three.longitude_ = 49;
    location_three.latitude_ = 33;
    location_three.index_ = 3;

    int shortest_path = Algorithms::shortestPath(multi_path, location_zero, location_three);
    int actual_distance = Graph::getDistance(location_zero, location_three);

    REQUIRE(shortest_path == actual_distance);
  }

  SECTION("Multiple edges away, larger data set") {
    Graph multi_path = f.read("testLarge.txt");
    map<Node, vector<Node>> adj_list =  multi_path.getAdjList();

    Node location_zero;
    Node location_three;
    Node location_four;
    Node location_five;
    Node location_eight;
    Node location_nine;

    location_zero.longitude_ = 25;
    location_zero.latitude_ = 11;
    location_zero.index_ = 0;

    location_three.longitude_ = 49;
    location_three.latitude_ = 33;
    location_three.index_ = 3;

    location_four.longitude_ = 90;
    location_four.latitude_ = 70;
    location_four.index_ = 4;

    location_five.longitude_ = 20;
    location_five.latitude_ = 100;
    location_five.index_ = 5;

    location_eight.longitude_ = 23;
    location_eight.latitude_ = 85;
    location_eight.index_ = 8;

    location_nine.longitude_ = 12;
    location_nine.latitude_ = 57;
    location_nine.index_ = 9;

    int shortest_path = Algorithms::shortestPath(multi_path, location_zero, location_nine);
    int actual_distance = Graph::getDistance(location_zero, location_three) 
    + Graph::getDistance(location_three, location_four) 
    + Graph::getDistance(location_four, location_five) 
    + Graph::getDistance(location_five, location_eight) 
    + Graph::getDistance(location_eight, location_nine);

    REQUIRE(shortest_path == actual_distance);
  }
}

TEST_CASE("Testing getDistance function", "[weight=1][part=1]") {
  Node nebraska; 
  nebraska.latitude_ = 41.507483;
  nebraska.longitude_ = -99.436554;

  Node kansas;
  kansas.latitude_ = 38.504048;
  kansas.longitude_ = -98.315949;

  float distance = Graph::getDistance(nebraska, kansas);

  // rounding to the tenths place
  distance = floor(10 * distance + 0.5f) / 10;

  REQUIRE(distance == 347.3f);
}

TEST_CASE("Testing adjacency list small with read in data") {
  //test that the adjacency matrix fills up correctly using small file  (e.g. test.txt)
  readFile f;
  Graph g = f.read("testSmall.txt");
  map<Node, vector<Node>> adj_list = g.getAdjList();

  Node location_one = createNode(30, -97, 0);
  Node location_two = createNode(30, -87, 1);
  Node location_three = createNode(20, -97, 2);

  SECTION("Node one has the correct adj nodes") {
    REQUIRE(listContainsNode(adj_list.at(location_one), location_two));
    REQUIRE(listContainsNode(adj_list.at(location_one), location_three));

    REQUIRE(adj_list.at(location_one).size() == 2);
  }

  SECTION("Node two has the correct adj nodes") {
    REQUIRE(listContainsNode(adj_list.at(location_two), location_one));
    REQUIRE(listContainsNode(adj_list.at(location_two), location_three));

    REQUIRE(adj_list.at(location_two).size() == 2);
  }

  SECTION("Node two has the correct adj nodes") {
    REQUIRE(listContainsNode(adj_list.at(location_three), location_two));
    REQUIRE(listContainsNode(adj_list.at(location_three), location_one));

    REQUIRE(adj_list.at(location_three).size() == 2);
  }
  
  SECTION("A nodes adj list should not contain itself") {
    REQUIRE(!listContainsNode(adj_list.at(location_three), location_three));
  }
}

TEST_CASE("Testing adjacency list large with read in data") {
  //test that the adjacency matrix fills up correctly using large file  (e.g. testLarge.txt)
  readFile f;
  Graph g = f.read("testLarge.txt");
  map<Node, vector<Node>> adj_list = g.getAdjList();

  Node location_zero = createNode(11, 25, 0);
  Node location_one = createNode(55, 44, 1);
  Node location_two = createNode(70, 10, 2);
  Node location_three = createNode(33, 49, 3);
  Node location_four = createNode(70, 90, 4);
  Node location_five = createNode(100, 20, 5);
  Node location_six = createNode(20, 40, 6);
  Node location_seven = createNode(80, 27, 7);
  Node location_eight = createNode(85, 23, 8);
  Node location_nine = createNode(57, 12, 9);
  Node location_ten = createNode(92, 65, 10);

  SECTION("Node zero has the correct adj nodes") {
    REQUIRE(listContainsNode(adj_list.at(location_zero), location_one));
    REQUIRE(listContainsNode(adj_list.at(location_zero), location_three));

    REQUIRE(adj_list.at(location_zero).size() == 2);
  }

  SECTION("Node one has the correct adj nodes") {
    REQUIRE(listContainsNode(adj_list.at(location_one), location_zero));
    REQUIRE(listContainsNode(adj_list.at(location_one), location_two));
    REQUIRE(listContainsNode(adj_list.at(location_one), location_six));

    REQUIRE(adj_list.at(location_one).size() == 3);
  }
  
  SECTION("Node two has the correct adj nodes") {
    REQUIRE(listContainsNode(adj_list.at(location_two), location_one));
    REQUIRE(listContainsNode(adj_list.at(location_two), location_three));

    REQUIRE(adj_list.at(location_two).size() == 2);
  }

  SECTION("Node three has the correct adj nodes") {
    REQUIRE(listContainsNode(adj_list.at(location_three), location_zero));
    REQUIRE(listContainsNode(adj_list.at(location_three), location_two));
    REQUIRE(listContainsNode(adj_list.at(location_three), location_four));

    REQUIRE(adj_list.at(location_three).size() == 3);
  }

  SECTION("Node four has the correct adj nodes") {
    REQUIRE(listContainsNode(adj_list.at(location_four), location_five));
    REQUIRE(listContainsNode(adj_list.at(location_four), location_three));

    REQUIRE(adj_list.at(location_four).size() == 2);
  }

  SECTION("Node five has the correct adj nodes") {
    REQUIRE(listContainsNode(adj_list.at(location_five), location_four));
    REQUIRE(listContainsNode(adj_list.at(location_five), location_seven));
    REQUIRE(listContainsNode(adj_list.at(location_five), location_eight));

    REQUIRE(adj_list.at(location_five).size() == 3);
  }

  SECTION("Node six has the correct adj nodes") {
    REQUIRE(listContainsNode(adj_list.at(location_six), location_one));
    REQUIRE(listContainsNode(adj_list.at(location_six), location_seven));

    REQUIRE(adj_list.at(location_six).size() == 2);
  }

  SECTION("Node seven has the correct adj nodes") {
    REQUIRE(listContainsNode(adj_list.at(location_seven), location_five));
    REQUIRE(listContainsNode(adj_list.at(location_seven), location_six));

    REQUIRE(adj_list.at(location_seven).size() == 2);
  }

  SECTION("Node eight has the correct adj nodes") {
    REQUIRE(listContainsNode(adj_list.at(location_eight), location_five));
    REQUIRE(listContainsNode(adj_list.at(location_eight), location_nine));

    REQUIRE(adj_list.at(location_eight).size() == 2);
  }

  SECTION("Node nine has the correct adj nodes") {
    REQUIRE(listContainsNode(adj_list.at(location_nine), location_eight));
    REQUIRE(listContainsNode(adj_list.at(location_nine), location_ten));

    REQUIRE(adj_list.at(location_nine).size() == 2);
  }

  SECTION("Node ten has the correct adj nodes") {
    REQUIRE(listContainsNode(adj_list.at(location_ten), location_nine));

    REQUIRE(adj_list.at(location_ten).size() == 1);
  }
}

TEST_CASE("Testing BFS algorithm- small test case") {
  readFile f;
  Graph g = f.read("testSmall.txt");

  Node location_one;
  Node location_two;
  Node location_three;

  location_one.longitude_ = -97;
  location_one.latitude_ = 30;
  location_one.index_ = 0;

  location_two.longitude_ = -87;
  location_two.latitude_ = 30;
  location_two.index_ = 1; 

  location_three.longitude_ = -97;
  location_three.latitude_ = 20;
  location_three.index_ = 2;
  
  map<Node, vector<Node>> list =  g.getAdjList(); 

  SECTION("Starting with node at zero index") {
    vector<int> results = Algorithms::BFSTraversal(g,location_one);
  
    REQUIRE(results[0] == 0);
    REQUIRE(results[1] == 1);
    REQUIRE(results[2] == 2);
  }

  SECTION("Starting with node at index one") {
    vector<int> results2 = Algorithms::BFSTraversal(g,location_two);

    REQUIRE(results2[0] == 1);
    REQUIRE(results2[1] == 0);
    REQUIRE(results2[2] == 2);
  }

  SECTION("Starting with node at index two") {
    vector<int> results3 = Algorithms::BFSTraversal(g,location_three);

    REQUIRE(results3[0] == 2);
    REQUIRE(results3[1] == 1);
    REQUIRE(results3[2] == 0);
  }
}

TEST_CASE("Testing BFS algorithm- MultiplePathsTest") {
  readFile f;
  Graph g = f.read("testMultiplePaths.txt");

  Node location_one;
  Node location_two;
  Node location_three;
  Node location_four;

  location_one.longitude_ = 25;
  location_one.latitude_ = 11;
  location_one.index_ = 0;


  location_two.longitude_ = 44;
  location_two.latitude_ = 55;
  location_two.index_ = 1; 

  location_three.longitude_ = 10;
  location_three.latitude_ = 70;
  location_three.index_ = 2;

  location_four.longitude_ = 49;
  location_four.latitude_ = 33;
  location_four.index_ = 3;

  map<Node, vector<Node>> list =  g.getAdjList(); 

  SECTION("Starting with node at zero index") {
    vector<int> results = Algorithms::BFSTraversal(g,location_one);
  
    REQUIRE(results[0] == 0);
    REQUIRE(results[1] == 1);
    REQUIRE(results[2] == 3);
    REQUIRE(results[3] == 2);
  }

  SECTION("Starting with node at index one") {
    vector<int> results2 = Algorithms::BFSTraversal(g,location_two);

    REQUIRE(results2[0] == 1);
    REQUIRE(results2[1] == 0);
    REQUIRE(results2[2] == 2);
    REQUIRE(results2[3] == 3);
  }
  
  SECTION("Starting with node at index two") {
    vector<int> results3 = Algorithms::BFSTraversal(g,location_three);

    REQUIRE(results3[0] == 2);
    REQUIRE(results3[1] == 1);
    REQUIRE(results3[2] == 3);
    REQUIRE(results3[3] == 0);
  }

  SECTION("Starting with node at index three") {
    vector<int> results3 = Algorithms::BFSTraversal(g,location_four);

    REQUIRE(results3[0] == 3);
    REQUIRE(results3[1] == 2);
    REQUIRE(results3[2] == 0);
    REQUIRE(results3[3] == 1);
  }
  
}

TEST_CASE("BFS Travesal- testLarge") {
  readFile f;
  Graph g = f.read("testLarge.txt");

  Node location_one;

  location_one.longitude_ = 25;
  location_one.latitude_ = 11;
  location_one.index_ = 0;

  map<Node, vector<Node>> list =  g.getAdjList(); 

  SECTION("Starting with node at zero index") {
    vector<int> results = Algorithms::BFSTraversal(g,location_one);
  
    REQUIRE(results[0] == 0);
    REQUIRE(results[1] == 1);
    REQUIRE(results[2] == 3);
    REQUIRE(results[3] == 2);
    REQUIRE(results[4] == 6);
    REQUIRE(results[5] == 4);
    REQUIRE(results[6] == 7);
    REQUIRE(results[7] == 5);
    REQUIRE(results[8] == 8);
    REQUIRE(results[9] == 9);
    REQUIRE(results[10] == 10);
  }

}

TEST_CASE("floydWarshall test small") {
  readFile f;
  Graph g = f.read("testSmall.txt");
  map<Node, int> freq_map = Algorithms::floydWarshall(g);
  map<int, int> indexed_freq_map;
  map<Node, int>::iterator it;
  for (it = freq_map.begin(); it != freq_map.end(); it++) {
    indexed_freq_map.insert({it->first.index_, it->second});
  }

  map<int, int> my_map;
  my_map.insert({0,2});
  my_map.insert({1,1});
  my_map.insert({2,0});

  map<int, int>::iterator it2;
  for (it2 = indexed_freq_map.begin(); it2 != indexed_freq_map.end(); it2++) {
    REQUIRE(indexed_freq_map[it2->first] == my_map[it2->first]);
  }
}

TEST_CASE("floydWarshall test medium") {
  readFile f;
  Graph g = f.read("testMedium.txt");
  map<Node, int> freq_map = Algorithms::floydWarshall(g);
  map<int, int> indexed_freq_map;
  map<Node, int>::iterator it;
  for (it = freq_map.begin(); it != freq_map.end(); it++) {
    indexed_freq_map.insert({it->first.index_, it->second});
  }

  map<int, int> my_map;
  my_map.insert({0,1});
  my_map.insert({1,4});
  my_map.insert({2,0});

  map<int, int>::iterator it2;
  for (it2 = indexed_freq_map.begin(); it2 != indexed_freq_map.end(); it2++) {
    REQUIRE(indexed_freq_map[it2->first] == my_map[it2->first]);
  }
}

TEST_CASE("floydWarshall test multiplePaths") {
  readFile f;
  Graph g = f.read("testMultiplePaths.txt");
  map<Node, int> freq_map = Algorithms::floydWarshall(g);
  map<int, int> indexed_freq_map;
  map<Node, int>::iterator it;
  for (it = freq_map.begin(); it != freq_map.end(); it++) {
    indexed_freq_map.insert({it->first.index_, it->second});
  }

  map<int, int> my_map;
  my_map.insert({0,5});
  my_map.insert({3,1});
  my_map.insert({1,2});
  my_map.insert({2,3});

  map<int, int>::iterator it2;
  for (it2 = indexed_freq_map.begin(); it2 != indexed_freq_map.end(); it2++) {
    REQUIRE(indexed_freq_map[it2->first] == my_map[it2->first]);
  }
}

TEST_CASE("floydWarshall test large") {
  readFile f;
  Graph g = f.read("testLarge.txt");
  map<Node, int> freq_map = Algorithms::floydWarshall(g);
  map<int, int> indexed_freq_map;
  map<Node, int>::iterator it;
  for (it = freq_map.begin(); it != freq_map.end(); it++) {
    indexed_freq_map.insert({it->first.index_, it->second});
  }
  map<int, int> my_map;
  my_map.insert({0,4});
  my_map.insert({1,11});
  my_map.insert({2,5});
  my_map.insert({3,10});
  my_map.insert({4,11});
  my_map.insert({5,27}); // <-Node with most traffic
  my_map.insert({6,4});
  my_map.insert({7,11});
  my_map.insert({8,18});
  my_map.insert({9,19});
  my_map.insert({10,0}); // <-Last node added to graph

  map<int, int>::iterator it2;
  for (it2 = indexed_freq_map.begin(); it2 != indexed_freq_map.end(); it2++) {
    REQUIRE(indexed_freq_map[it2->first] == my_map[it2->first]);
  }
}

TEST_CASE("betweenness centrality test small") {
  readFile f;
  Graph g = f.read("testSmall.txt");
  int most_freq_node = Algorithms::betweennessCentrality(g).index_;
  REQUIRE(most_freq_node == 0);
}

TEST_CASE("betweenness centrality test medium") {
  readFile f;
  Graph g = f.read("testMedium.txt");
  int most_freq_node = Algorithms::betweennessCentrality(g).index_;
  REQUIRE(most_freq_node == 1);
}

TEST_CASE("betweenness centrality test multiplePaths") {
  readFile f;
  Graph g = f.read("testMultiplePaths.txt");
  int most_freq_node = Algorithms::betweennessCentrality(g).index_;
  REQUIRE(most_freq_node == 0);
}