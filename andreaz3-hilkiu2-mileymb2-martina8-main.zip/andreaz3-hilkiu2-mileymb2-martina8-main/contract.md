Team Contract: andreaz3-hilkiu2-mileymb2-martina8

Team Meetings: 
We will meet Modays and Wednesdays at 12 for an hour each.
We plan to meet in person if possible but zoom if someone has complications 

Assistance: 
We will contact one another over text if we need each other's opinions. We should expect a response within 24 hours. 

Respect: 
We will make sure that everyone’s ideas are heard and everyone's input is taken into 
consideration when making decisions regarding the group project. We will make sure 
to implement ideas after everyone has agreed on changes.

Collaboration:
We will be evenly distributed among all 4 of the team members. If one of us is stuck or comes across an 
unexpected complication in their portion of the work, we will all meet together 
and try to figure out a solution to this complication together. 

Time Commitment:
Each group member is expected to work at least 5 hours a week or more if necessary. 
We have already accounted for prior commitments by planning our meeting times around them.
We will address new conflicts or commitments when they occur by being open to new meeting times and being flexible with our schedules. 

Conflict Resolution:
Everyone will meet together to discuss what the disagreement is and how we can resolve it. 
If issues persist, we can meet with our mentor to have them facilitate discussions. If someone 
is not accomplishing their tasks, then we will also meet to address the issue and again, if the issue 
continues we will also meet with our mentor to discuss options. 
 
Signing Contract:
Helen Ilkiu
Andrea Zhou
Martina Perez Zuleta
Miley Brunner

 
 

